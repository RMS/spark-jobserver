**Used Spark version**

**Used Spark Job Server version**
(Released version, git branch or docker image version)

**Deployed mode**
(client/cluster on Spark Standalone/YARN/Mesos/EMR or default)

**Actual (wrong) behavior**

**Steps to reproduce**

**Logs**

```
some log
```

or as attached file (see below)


Unused parts of this template should be removed (including this line).
