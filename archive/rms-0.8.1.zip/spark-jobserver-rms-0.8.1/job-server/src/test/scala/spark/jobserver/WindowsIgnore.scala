package spark.jobserver

import org.scalatest.Tag

object WindowsIgnore extends Tag ("WindowsIgnore")
