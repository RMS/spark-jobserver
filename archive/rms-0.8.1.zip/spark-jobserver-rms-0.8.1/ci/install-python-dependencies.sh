#!/usr/bin/env bash
set -e
pip install --upgrade pip
pip install --user pyhocon
pip3 install --user pyhocon
pip install --user pep8
